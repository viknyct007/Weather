CENTRAL PARK WEATHER PREDICTOR

This version uses a tiny local server as a proxy for the NWS API.
That fixes the browser User-Agent/CORS issue in the previous standalone HTML.

Requirements:
- Python 3
- Internet access

Run:
1. Open Terminal/Command Prompt in this folder.
2. Run: python server.py
3. Open: http://127.0.0.1:8000

The page refreshes automatically every 10 minutes and has a Refresh now button.
The backend checks the NWS /points mapping, then fetches the current KNYC observation
and NWS hourly forecast. It uses a 60-second backend cache to avoid excessive API requests.
